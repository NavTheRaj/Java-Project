import java.io.IOException;
import com.fazecast.jSerialComm.SerialPort;
import java.util.*;
 
public class SerialCon{
 
    public int SerialCon (int num) throws IOException, InterruptedException {
    SerialPort sp = SerialPort.getCommPort("COM4"); // device name TODO: must be changed
    sp.setComPortParameters(9600, 8, 1, 0); // default connection settings for Arduino
    sp.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 0, 0); // block until bytes can be written
    
    if (sp.openPort()) {
      System.out.println("Port is open :)");
    } else {
      System.out.println("Failed to open port :(");
      return 1;
    }   
    //Scanner sc= new Scanner(System.in);
    
    
    for (int j = 1; j<50; j++)
    {
    //System.out.println("enter 1 or 2: "); 
    //Integer i = sc.nextInt();
    Integer k = num;
      sp.getOutputStream().write(k.byteValue());
      sp.getOutputStream().write(k.byteValue());
      //System.out.println("Sent number: " + i);
      Thread.sleep(100);  
      }
    
    if (sp.closePort()) {
      System.out.println("Port is closed :)");
    } else {
      System.out.println("Failed to close port :(");
      return 1;
    }
    return 1;
  }
    
}
