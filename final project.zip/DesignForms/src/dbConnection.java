 
import java.awt.List;
import javax.swing.JFrame;
import javax.swing.Timer;
import model.Box;
 import java.sql.*;
import java.util.ArrayList;

public class dbConnection {
    Statement stmt = null;
    Connection con = null;
    ResultSet rs=null;
     int lid;
  //  ResultSet rs2=null;
   
    public dbConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medicine","root","");
            stmt=con.createStatement();
        }catch(ClassNotFoundException | SQLException e){ System.out.println(e);} 
        
    }
    //For registering the patientis information into database
   public int ExecuteQuery(String name,int contact,String password){
        try{
//        String sql = "insert into patientdb(name,pw,phone) values("+"name"+","+"password"+","+"contact"+")";
             String sql = "insert into patientdb(name,pw,phone) values("+"'"+name+"',"+"'"+password+"',"+contact+")";
        System.out.println(sql);
       stmt.executeUpdate(sql);
        MessageBox b = new MessageBox();
         
            b.setMessage("Registered Successfully.....");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
            b.start_timer(b);
         
          return lid;
//         LoginForm lf=new LoginForm();
//        lf.setVisible(true);
//        lf.pack();
//        lf.setLocationRelativeTo(null);
//        lf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
           
        }catch(Exception e){
           System.err.println("Error Inserting......"+e);
          
           MessageBox b = new MessageBox();
         
            b.setMessage("Error connecting.....");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
         return -1;
            
        }
        
    }
   
   //For login Confirmation
   public int Login(String username,String password) {
    try {
      
        if (username != null && password != null) {
            String sql = "Select * from patientdb Where name='" + username + "' and pw='" + password + "'";
               System.out.println(sql);
            rs = stmt.executeQuery(sql);
            
          
          
            
            if (rs.next()) {
                lid= rs.getInt(1);
                System.out.print("our id:"+lid);
                MessageBox mb=new MessageBox();
                  mb.setMessage("Logged In");
                mb.setVisible(true);
                mb.start_timer(mb);
                return lid;
                //BoxForm bf=new BoxForm();
                //bf.setVisible(true);
                
                
                
   } else {
                 MessageBox b = new MessageBox();
             b.setMessage("Username or Password not valid!!");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
            return -1;
                
            }  
            
        }

        // You can also validate user by result size if its comes zero user is invalid else user is valid

    } catch (SQLException e) {
        System.err.println("Error Inserting......"+e);
           MessageBox b = new MessageBox();
            b.setMessage("No network connection.....");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
    }
return -1;
}
   //For inseritng the medicines and its information into database
    public void Boxdb(String name,String exdate,int interval,String box,int lid) {
        try{
//        String sql = "insert into patientdb(name,pw,phone) values("+"name"+","+"password"+","+"contact"+")";
             String sql = "insert into meddb(name,exdate,time_interval,box,p_id) values("+"'"+name+"',"+"'"+exdate+"',"+interval+",'"+box+"',"+lid+")";
             System.out.println(sql);
            // String sql = " INSERT INTO meddb(name,exdate,interval,box)" + "VALUES(?,?,?,?)";
        System.out.println(sql);
       stmt.executeUpdate(sql);
       
        MessageBox mb=new MessageBox();
        mb.setMessage("Inserted to database");
      mb.toFront();
      mb.setVisible(true);
      mb.start_timer(mb);
       
           
        }catch(Exception e){
              System.err.println("Error Inserting......"+e.getMessage());
           MessageBox b = new MessageBox();
            b.setMessage("Error connecting.....");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
         
            
        }
        
    }
    
    
    //reSet code 
     public int ResetBox(int n,int lid)
     {
         
      try{
          String sql = "DELETE FROM `meddb` WHERE box = '"+n+"' and p_id = '"+lid+"'";
          System.out.println(sql);
          stmt.executeUpdate(sql);
          return 1;
      }
      catch(Exception e){
          System.err.println("Error......"+e.getMessage());
           MessageBox b = new MessageBox();
            b.setMessage("Error.....");
            b.toFront();
            b.setVisible(true);
            b.start_timer(b);
            return -1;
      }
     
     }
     //Reset Code END
    
    public String getData(int lid, int boxn, String data){
        String result="null";
        try{
    String sql = "SELECT * FROM `meddb` WHERE p_id = '"+lid+"' AND box='"+boxn+"'";
    System.out.println(sql);
        rs= stmt.executeQuery(sql);
        while (rs.next()) {
        result = rs.getString(data); 
        System.out.println("result: "+result);
        return result;
        }
        }
        catch(Exception e) {
            
        }
return result;
}
    
  
 
     
     
     
     
     
     
    
//    public List<Box> med_Detail(String box, int lid)
//    {
//        List <Box> blist=new ArrayList <Box>();
//        try{
//             String sql = "Select * from meddb Where p_id=" + lid+ " and box= '" + box + "'";
//             System.out.println(sql);
//              rs = stmt.executeQuery(sql);
//              System.out.println("our new id:"+lid);
//              
//            while (rs.next())
//      {
//
//        String name = rs.getString("name");
//        String exdate = rs.getString("exdate");
//        int time_interval = rs.getInt("time_interval");
//     
//        String medinfo [] = {name,exdate,Integer.toString(time_interval)};
//
//         
//  // print the results
//        System.out.println("name: "+name+" Exdate: "+exdate+" Time Interval"+time_interval);
//        return medinfo[1];
//      }
//              
//             
//        }
//        catch(Exception e){
//         System.err.println("Error retrieving data....."+e.getMessage());  
//         Message Box b=new MessageBox();
//        b.setMessage("Error retriving the data");
//        }
//     return blist;   
//    }
    
    
    
    
}
