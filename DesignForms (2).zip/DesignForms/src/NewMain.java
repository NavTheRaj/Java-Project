 
public class NewMain {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        StartApp st=new StartApp();
        st.setVisible(true);
        
    }
}
    

